const AppMessages = {
    INTERNEt_NOT_FOUND:'Internet Connection Not Found.',
    FULL_NAME_NOT_BLANK:'Full name cannot be blank.',
    EMAIL_NOT_BLANK:'Email cannot be blank.',
    PHONE_NOT_BLANK:'Phone cannot be blank.',
    MESSAGE_NOT_BLANK:'Message cannot be blank.',

    WelcomeAR:'',
    LoginAR:'',
    ContactusAR:'',
    YardAR:'',
    CarTrackingAR:'',
    ContainerTrackingAR:'',
    ServicesAR:'',

    

}

export default AppMessages;