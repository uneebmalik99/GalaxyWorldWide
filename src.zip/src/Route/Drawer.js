import React from "react";
import { View, StyleSheet, Image } from "react-native";
import {
  useTheme,
  Avatar,
  Title,
  Caption,
  Paragraph,
  Drawer,
  Text,
  TouchableRipple,
  Switch,
} from "react-native-paper";
import { DrawerContentScrollView, DrawerItem } from "@react-navigation/drawer";

import Icon from "react-native-vector-icons/MaterialCommunityIcons";
import AntDesign from "react-native-vector-icons/dist/AntDesign";
import FontAwesome from "react-native-vector-icons/dist/FontAwesome";
import FontAwesome5 from "react-native-vector-icons/FontAwesome5";
import MaterialIcons from "react-native-vector-icons/dist/MaterialIcons";

import Welcome from "../screens/Welcome";
import Signin from "../screens/Signin";
import Contactus from "../screens/Contactus";
import AppConstance, {
  deviceHeight,
  deviceWidth,
} from "../constance/AppConstance";
import { SafeAreaView } from "react-native-safe-area-context";
import Tracking from "../screens/Tracking";
import Dashboard from "../screens/Dashboard";
import CarDetails from "../screens/CarDetails";
import alerts from "../screens/alerts";
import ContainerCarlist from "../screens/ContainerCarlist";
import TrackingSearchDetails from "../screens/TrackingSearchDetails";
import Prices from "../screens/Prices";
import Notifications from "../screens/Notifications";
import Towing from "../screens/Towing";
import Warehousing from "../screens/Warehousing";
import Shipping from "../screens/Shipping";
import Accounts from "../screens/Accounts";
import yard from "../screens/yard";
import services from "../screens/services";
import container from "../screens/container";
import Dashboardmain from "../screens/Dashboardmain";
import Accountsview from "../screens/Accountsview";
import carslist from "../screens/carslist";
import invoicelist from "../screens/invoicelist";
import containerinfo from "../screens/containerinfo";
import invoiceview from "../screens/invoiceview";
import AsyncStorage from "@react-native-community/async-storage";

export function DrawerContent(props) {
  const paperTheme = useTheme();
  const signOut = async () => {
    await AsyncStorage.removeItem(AppConstance.USER_INFO_OBJ);
    await AsyncStorage.setItem("ISUSERLOGIN", "0");
    AppConstance.IS_USER_LOGIN = "0";
    AppConstance.USER_INFO_OBJ = [];
    alert("sd");
    props.navigation.navigate("Welcome");
  };

  // const { signOut, toggleTheme } = React.useContext(AuthContext);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#29AB87" }}>
      <View style={{ backgroundColor: "#1B55A3" }}>
        <View style={styles.userInfoSection}>
          <View
            style={{
              marginTop: 15,
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Image
              style={{ width: 150, height: 100, alignSelf: "center" }}
              source={require("../images/logofinal3.jpg")}
            />
            <View style={{ marginLeft: 15, flexDirection: "column" }}>
              {/* <Title style={styles.title}>John Doe</Title> */}
              <Title style={styles.title}>
                {AppConstance.USER_INFO.USER_NAME}
              </Title>
              <Caption style={styles.caption}>
                {AppConstance.USER_INFO.USER_EMAIL}
              </Caption>
            </View>
          </View>
        </View>
      </View>
      <View style={styles.drawerContent}>
        <DrawerContentScrollView style={{ paddingVertical: 0 }} {...props}>
          <Drawer.Section style={styles.drawerSection}>
            <DrawerItem
              icon={({ color, size }) => (
                <Icon name="home-outline" color='white' size={size} />
              )}
              label="DASHBOARD"
              labelStyle={{color:'white'}}

              onPress={() => {
                props.navigation.navigate("Dashboardmain");
              }}
            />
            <DrawerItem
              icon={({ color, size }) => (
                <Icon name="car" size={size} color='white' />
              )}
              label="VEHICLE"
              labelStyle={{color:'white'}}

              onPress={() => {
                props.navigation.navigate("VehcileScreen", { type: "0" });
              }}
            />
            <DrawerItem
              icon={({ color, size }) => (
                <FontAwesome name="ship" size={size - 2} color='white' />
              )}
              label="CONTAINER"
              labelStyle={{color:'white'}}

              labelStyle={{color:'white'}}

              onPress={() => {
                props.navigation.navigate("ContainerCarlist");
              }}
            />
            <DrawerItem
              icon={({ color, size }) => (
                <FontAwesome5 name="file-invoice" size={size} color='white' />
              )}
              label="INVOICE"
              labelStyle={{color:'white'}}

              onPress={() => {
                props.navigation.navigate("invoicelist");
              }}
            />
            <DrawerItem
              icon={({ color, size }) => (
                <AntDesign name="customerservice" size={size} color='white' />
              )}
              label="SERVICES"
              labelStyle={{color:'white'}}

              onPress={() => {
                props.navigation.navigate("services");
              }}
            />

            <DrawerItem
              icon={({ color, size }) => (
                <MaterialIcons name="announcement" size={size} color='white' />
              )}
              label="ANNOUNCEMENT"
              labelStyle={{color:'white'}}

              labelStyle={{color:'white'}}
              onPress={() => {
                props.navigation.navigate("ANNOUNCEMENT");
              }}
            />

            <DrawerItem
              icon={({ color, size }) => (
                <Icon name="map-marker-radius" size={size} color='white' />
              )}
              label="OUR LOCATION"
              labelStyle={{color:'white'}}

              onPress={() => {
                props.navigation.navigate("yard");
              }}
            />

            <DrawerItem
              icon={({ color, size }) => (
                <MaterialIcons name="contact-mail" size={size} color='white' />
              )}
              label="CONTACT US"
              labelStyle={{color:'white'}}

              onPress={() => {
                props.navigation.navigate("Contactus");
              }}
            />
          </Drawer.Section>
        </DrawerContentScrollView>
        <Drawer.Section style={styles.bottomDrawerSection}>
          <DrawerItem
            icon={({ color, size }) => (
              <Icon name="exit-to-app" color='white' size={size} />
            )}
            label="LOG OUT"
            labelStyle={{color:'white'}}

            onPress={() => {
              signOut();
            }}
          />
        </Drawer.Section>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  drawerContent: {
    backgroundColor: "#1B55A3",
    borderTopLeftRadius: 35,
    width: "85%",
    justifyContent: "flex-start",
    height: "84%",
    paddingBottom: 8,
    alignSelf: "flex-end",
  },
  userInfoSection: {
    paddingVertical: 5,
    backgroundColor: "#29AB87",
    borderBottomRightRadius: 35,
  },
  title: {
    fontSize: 16,
    fontWeight: "bold",
    color: 'white',
  },
  caption: {
    fontSize: 14,
    lineHeight: 14,
    color: 'white'
  },
  row: {
    marginTop: 20,
    flexDirection: "row",
    alignItems: "center",
  },
  section: {
    flexDirection: "row",
    alignItems: "center",
    marginRight: 15,
  },
  paragraph: {
    fontWeight: "bold",
    marginRight: 3,
  },
  drawerSection: {
    marginTop: 0,
  },
  bottomDrawerSection: {
    marginBottom: 15,
    // backgroundColor: "#1B55A3",
    // borderTopWidth: 1,
  },
  preference: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
});
