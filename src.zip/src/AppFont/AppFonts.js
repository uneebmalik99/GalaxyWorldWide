const AppFonts = {
    SourceSansProRegular: 'SourceSansPro-Regular',
    SourceSansProBlack: 'SourceSansPro-Black',
    SourceSansProLight: 'SourceSansPro-Light',
    SourceSansProSemiBold: 'SourceSansPro-SemiBold',
    SourceSansProBold:'SourceSansPro-Bold',
    JosefinSansBold:'JosefinSans-Bold',
    JosefinSansLight:'JosefinSans-Light',
    JosefinSansRegular:'JosefinSans-Regular',
    JosefinSansSemiBold:'JosefinSans-SemiBold',
    JosefinSansThin:'JosefinSans-Thin'
}
export default AppFonts;