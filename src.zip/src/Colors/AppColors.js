const AppColors = {
    toolbarColor: '#008B8B',
    appBackColor: '#f5f5f5',
    white: '#ffffff',
    black: '#000000',
    purple:'#6770ce',
    btnLoginColor: '#6658dd',
    transplant: '#00000000',
    blue:'#116bb9',
    textColor: 'black',
    Headercolor: '#eaecee',
    Cyton: '#abb2b9',
    bg: 'rgba(255,255,255,0.87)',
    Signincolor: 'rgb(4, 175, 192)',
    signinplaceholdercolor: '#8c898e',
    signindivider: '#cbc9d0',
    transplantColor: '#00000000',
    appbarColor: '#1B55A3'
  };
  export default AppColors;