import React, { useState, useEffect } from "react";
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  ImageBackground,
  FlatList,
  StatusBar,
  TouchableOpacity,
  Image,
  Dimensions,
  Modal,
} from "react-native";
import Icon from "react-native-vector-icons/Entypo";
import AppColors from "../Colors/AppColors";
import AppConstance, {
  deviceHeight,
  deviceWidth,
} from "../constance/AppConstance";
import AppFonts from "../AppFont/AppFonts";
import MaterialCommunityIcons from "react-native-vector-icons/dist/MaterialCommunityIcons";
import AntDesign from "react-native-vector-icons/dist/AntDesign";
import FontAwesome from "react-native-vector-icons/dist/FontAwesome";
import SimpleLineIcons from "react-native-vector-icons/dist/SimpleLineIcons";
import Feather from "react-native-vector-icons/dist/Feather";
import AppUrlCollection from "../UrlCollection/AppUrlCollection";
import Ionicons from "react-native-vector-icons/dist/Ionicons";
import NetInfo from "@react-native-community/netinfo";

import Spinner from "react-native-loading-spinner-overlay";
import { DrawerContentScrollView } from "@react-navigation/drawer";

const Dashboardmain = ({ navigation }) => {
  const [Dashboarddata, setDashboarddata] = useState();
  const [spinner, setspinner] = useState(false);

  const [modalVisible, setModalVisible] = useState(false);
  const callingdashboardApi = () => {
    NetInfo.fetch().then((state) => {
      if (state.isConnected == true) {
        var url = "";

        url = AppUrlCollection.BASE_URL + "vehicle/get-vehicle-counter";

        fetch(url, {
          method: "GET",
          headers: {
            "Content-Type": "multipart/form-data",
            authkey: AppConstance.USER_INFO.USER_TOKEN,
          },
        })
          .then((response) => response.json())
          .then((responseJson) => {
            //this.setState({ isLoading: false })
            if (responseJson.status == AppConstance.API_SUCESSCODE) {
              setDashboarddata(responseJson.data);
              // alert(JSON.stringify(responseJson.data))
              console.warn("data is " + Dashboarddata);
              // console.log("aya")
            } else {
              alert(responseJson.message);
              // AppConstance.showSnackbarMessage(responseJson.message)
            }
          })
          .catch((error) => {
            alert(error);
            console.warn(error);
          });
      } else setModalVisible(true);
    });
  };


  useEffect(() => {
    callingdashboardApi();

    return () => {};
  }, []);

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: AppColors.transplant,
        height: deviceHeight,
      }}
    >
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          Alert.alert("Modal has been closed.");
          setModalVisible(!modalVisible);
        }}
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <Text style={styles.modalText}>
              Connect to the Internet and Retry
            </Text>
            <View style={styles.modalBtn}>
              <TouchableOpacity
                style={[styles.button, styles.buttonClose]}
                onPress={() => {
                  setModalVisible(!modalVisible);
                }}
              >
                <Text style={styles.textStyle}>Close</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.button, styles.buttonClose]}
                onPress={() => {
                  setModalVisible(!modalVisible);
                  callingdashboardApi();
                }}
              >
                <Text style={styles.textStyle}>Retry</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Image
        source={require("../images/backgroundimage.jpg")}
        resizeMode="stretch"
        style={{
          width: deviceWidth,
          height: deviceHeight,
          position: "absolute",
        }}
      />
      <View
        style={{
          width: deviceWidth,
          flexDirection: "row",
          paddingHorizontal: 13,
          paddingVertical: 15,
          height: 55,
        }}
      >
        <TouchableOpacity
          style={{ justifyContent: "center", width: "6%" }}
          onPress={() => navigation.openDrawer()}
        >
          <Ionicons name="ios-menu-outline" size={25} color="white" />
        </TouchableOpacity>

        <View style={{ width: "88%", justifyContent: "center" }}>
          <Text
            style={{
              alignSelf: "center",
              color: "white",
              fontWeight: "bold",
              fontSize: 20,
            }}
          >
            Dashboard
          </Text>
        </View>

        <TouchableOpacity
          style={{ justifyContent: "center", width: "6%" }}
        ></TouchableOpacity>
      </View>
      {/* <Image source={require('../Images/app_back_image.jpg')} resizeMode='stretch' style={{ width: deviceWidth, height: deviceHeight * 0.33, position: 'absolute' }} /> */}
      <View style={{ flex: 1 }}>
        <View
          style={{
            width: deviceWidth * 0.8,
            height: 90,
            justifyContent: "center",
            alignSelf: "center",
            marginTop: 30,
          }}
        >
          <Image
            source={require("../images/logofinal3.jpg")}
            style={{ width: undefined, height: undefined, flex: 1 }}
            resizeMode="contain"
          />
          {/* <Text style={{ fontFamily: AppFonts.JosefinSansSemiBold, fontSize: 20, color: AppColors.textColor }}>OUR SERVICES</Text> */}
        </View>

        <View style={styles.main_item}>
          <TouchableOpacity
            onPress={() => {
              //   navigation.navigate("VehicleList", { type: "4" });
              navigation.navigate("VehcileScreen", { type: "0" });
            }}
            style={styles.item}
          >
            <Image
              source={require("../images/vehicleiconblack.png")}
              style={{ width: 60, height: 60, alignSelf: "center" }}
              resizeMode="contain"
            />
            <Text style={styles.item_text}>All Vehicles</Text>
            <Text style={styles.item_count}>
              {Dashboarddata == null ? "-" : Dashboarddata.all}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => {
              navigation.navigate("VehcileScreen", { type: "6" });
            }}
            style={styles.item}
          >
            <Image
              source={require("../images/vehicleiconblack.png")}
              style={{ width: 60, height: 60, alignSelf: "center" }}
              resizeMode="contain"
            />
            <Text style={styles.item_text}>New Purchase</Text>
            <Text style={styles.item_count}>
              {Dashboarddata == null ? "-" : Dashboarddata.new_purchase}
            </Text>
            {/* {this.state.arrived} */}
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => {
              navigation.navigate("VehcileScreen", { type: "1" });
            }}
            style={styles.item}
          >
            <Image
              source={require("../images/caronhand.png")}
              style={{ width: 60, height: 60, alignSelf: "center" }}
              resizeMode="contain"
            />
            <Text style={styles.item_text}>On Hand</Text>
            <Text style={styles.item_count}>
              {Dashboarddata == null ? "-" : Dashboarddata.on_hand}
            </Text>
            {/* {this.state.arrived} */}
          </TouchableOpacity>
        </View>

        <View style={styles.main_item}>
          <TouchableOpacity
            onPress={() => {
              navigation.navigate("VehcileScreen", { type: "2" });
            }}
            style={styles.item}
          >
            <Image
              source={require("../images/readyforrenticon.png")}
              style={{ width: 60, height: 60, alignSelf: "center" }}
              resizeMode="contain"
            />
            <Text style={styles.item_text}>Ready to Ship</Text>
            <Text style={styles.item_count}>
              {/* {this.state.shipped} */}
              {Dashboarddata == null ? "-" : Dashboarddata.all}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => {
              navigation.navigate("VehcileScreen", { type: "3" });
            }}
            style={styles.item}
          >
            <Image
              source={require("../images/towtruck.png")}
              style={{ width: 60, height: 60, alignSelf: "center" }}
              resizeMode="contain"
            />
            <Text style={styles.item_text}>On The Way</Text>
            <Text style={styles.item_count}>
              {/* {this.state.shipped} */}
              {Dashboarddata == null ? "-" : Dashboarddata.car_on_way}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => {
              navigation.navigate("VehcileScreen", { type: "10" });
            }}
            style={styles.item}
          >
            <Image
              source={require("../images/googlemapmarker.png")}
              style={{ width: 60, height: 60, alignSelf: "center" }}
              resizeMode="contain"
            />
            <Text style={styles.item_text}>Arrived</Text>
            <Text style={styles.item_count}>
              {/* {this.state.shipped} */}
              {Dashboarddata == null ? "-" : Dashboarddata.arrived}
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.main_item}>
          <TouchableOpacity
            onPress={() => {
              // navigation.navigate("VehcileScreen", { type: "4" });
              navigation.navigate("ContainerCarlist");
            }}
            style={styles.item}
          >
            <Image
              source={require("../images/readyforrenticon.png")}
              style={{ width: 60, height: 60, alignSelf: "center" }}
              resizeMode="contain"
            />
            <Text style={styles.item_text}>Container</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => {
              navigation.navigate("Accounts");
            }}
            style={styles.item}
          >
            <Image
              source={require("../images/accountingicon.png")}
              style={{ width: 60, height: 60, alignSelf: "center" }}
              resizeMode="contain"
            />
            <Text style={styles.item_text}>Accounting</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => {
              navigation.navigate("EditVehicleContainer");
            }}
            style={styles.item}
          >
            <Image
              source={require("../images/accountingicon.png")}
              style={{ width: 60, height: 60, alignSelf: "center" }}
              resizeMode="contain"
            />
            <Text style={styles.item_text}>Custom</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default Dashboardmain;

const styles = StyleSheet.create({
  main_item: {
    flexDirection: "row",
    width: "90%",
    marginTop: 20,
    alignSelf: "center",
    justifyContent: "space-around",
  },
  item: {
    // backgroundColor:'white',
    borderWidth: 0.8,
    borderColor: "white",
    width: "30%",
    // padding:20,
    height: 150,
    paddingVertical: 5,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10,
  },
  item_text: {
    color: "white",
    paddingVertical: 5,
    alignSelf: "center",
  },
  item_count: {
    color: "white",
    alignSelf: "center",
  },

  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22,
  },
  modalView: {
    margin: 20,
    backgroundColor: "white",
    borderRadius: 20,
    padding: 35,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
    margin: 5,
  },
  buttonClose: {
    backgroundColor: "#2196F3",
  },
  textStyle: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center",
  },
  modalBtn: {
    flexDirection: "row",
    justifyContent: "center",
  },
});
