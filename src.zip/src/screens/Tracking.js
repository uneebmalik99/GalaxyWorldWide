import React from "react";
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  ImageBackground,
  TextInput,
  StatusBar,
  TouchableOpacity,
  Image,
  FlatList,
  Modal,
  Dimensions,
  TouchableHighlight,
} from "react-native";
import Icon from "react-native-vector-icons/Entypo";
import AppColors from "../Colors/AppColors";
import AppConstance, {
  deviceHeight,
  deviceWidth,
} from "../constance/AppConstance";
import AppFonts from "../AppFont/AppFonts";
import MaterialCommunityIcons from "react-native-vector-icons/dist/MaterialCommunityIcons";
import AntDesign from "react-native-vector-icons/dist/AntDesign";
import FontAwesome from "react-native-vector-icons/dist/FontAwesome";
import Ionicons from "react-native-vector-icons/dist/Ionicons";
import MaterialIcons from "react-native-vector-icons/dist/MaterialIcons";
import Feather from "react-native-vector-icons/dist/Feather";
import Fontisto from "react-native-vector-icons/dist/Fontisto";
import FontAwesome5 from "react-native-vector-icons/dist/FontAwesome5";
import { useState } from "react";
import Spinner from "react-native-loading-spinner-overlay";
import AppUrlCollection from "../UrlCollection/AppUrlCollection";
import VehcileScreen from "./VehcileScreen";
import NetInfo from '@react-native-community/netinfo'

 
let imageBasePath;
const Tracking = ({ navigation }) => {
  const [vehicleList, setvehicleList] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);

  const [spinner, setspinner] = useState(false);
  const [search, setsearch] = useState("");
  const [res, setres] = useState("0");
  const onChangeText = (Text) => {
    setsearch(Text);
  };

  const searchingApi = () => {
    NetInfo.fetch().then((state) => {
      if (state.isConnected == true) {
      setspinner(true);

    var url = "";
    url =
      AppUrlCollection.VEHICLE_CONTAINER + "search_str=" + search + "&page=1";

    fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        // 'authkey': AppConstance.USER_INFO.USER_TOKEN
      },
    })
      .then((response) => response.json())
      .then((responseJson) => {
        console.warn("response");
        if (responseJson.status == AppConstance.API_SUCESSCODE) {
          console.warn(
            "response of trackinh seach is :::::::::::" +
              responseJson.data.export
          );
          let data = responseJson.data.vehicleList;
          imageBasePath = responseJson.data.other.vehicle_image;
          setvehicleList(responseJson.data.vehicleList);
          setspinner(false);

          console.warn(data.length);
          setres(data.length);

        } else {
          setspinner(false);

        }
      })
      .catch((error) => {
        setspinner(false);

        alert(error);
        console.warn(error);
      });
      }else setModalVisible(true);
    })


  };

  const renderVehicle = ({ item, index }) => {
    return (
      <TouchableOpacity
        style={{
          width: "100%",
          height: 80,
          borderRadius: 5,
          marginTop: 5,
          borderWidth: 0.4,
          borderColor: "white",
          flexDirection: "row",
        }}
        onPress={()=>navigation.navigate("CarDetails",{vehicleObj: item})}
      >
        <View
          style={{ width: "30%", justifyContent: "center", height: 80 }}
          // onPress = {()=>this.callingVehicleDetailSCreen(item)}
        >
          {item.images.length > 0 ? (
            <Image
              style={{ width: undefined, height: undefined, flex: 1 }}
              source={{ uri: imageBasePath + item.images[0].thumbnail }}
            />
          ) : (
            <Image
              style={{
                width: undefined,
                height: undefined,
                flex: 1,
                resizeMode: "stretch",
                borderRadius: 5,
              }}
              source={require("../images/logofinal3.jpg")}
            />
          )}
        </View>
        <View style={{ width: "5%" }}></View>
        <View
          style={{ width: "64%", height: "100%", justifyContent: "center" }}
        >
          <Text style={{ color: "white" }}>
            {item.year} {item.make} {item.model}
          </Text>
          <Text style={{ color: "white" }}>
            {item.location == 2
              ? "GA"
              : item.location == 4
              ? "TX"
              : item.location == 1
              ? "LA"
              : item.location == 8
              ? "TORONTO"
              : item.location == 9
              ? "MONTREAL"
              : item.location == 12
              ? "GALGARY"
              : item.location == 10
              ? "HALIFAX"
              : "NY"}{" "}
            | {item.lot_number}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView
      style={{ backgroundColor: AppColors.transplant, height: deviceHeight }}
    >
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          Alert.alert("Modal has been closed.");
          setModalVisible(!modalVisible);
        }}
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <Text style={styles.modalText}>
              Connect to the Internet and Retry
            </Text>
            <View style={styles.modalBtn}>
            <TouchableOpacity
              style={[styles.button, styles.buttonClose]}
              onPress={() => {
                setModalVisible(!modalVisible);
              }}
            >
              <Text style={styles.textStyle}>Close</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.button, styles.buttonClose]}
              onPress={() => {
                setModalVisible(!modalVisible);
                searchingApi(search);
              }}
            >
              <Text style={styles.textStyle}>Retry</Text>
            </TouchableOpacity>
            
            </View>
          </View>
        </View>
      </Modal>
      <Spinner
        visible={spinner}
        textContent={"Loading..."}
        textStyle={{ color: "#FFF" }}
      />

      <ImageBackground
        source={require("../images/backgroundimage.jpg")}
        resizeMode="stretch"
        style={{
          width: deviceWidth,
          height: deviceHeight,
          position: "absolute",
        }}
      ></ImageBackground>

      <View
        style={{
          width: deviceWidth,
          flexDirection: "row",
          paddingHorizontal: 13,
          paddingVertical: 15,
          height: 55,
        }}
      >
        <TouchableOpacity
          style={{ justifyContent: "center", width: "6%" }}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="chevron-back" size={25} color="white" />
        </TouchableOpacity>

        <View style={{ width: "88%", justifyContent: "center" }}>
          <Text
            style={{
              alignSelf: "center",
              color: "white",
              fontWeight: "bold",
              fontSize: 20,
            }}
          >
            Car Tracking{" "}
          </Text>
        </View>

        <TouchableOpacity
          style={{ justifyContent: "center", width: "6%" }}
        ></TouchableOpacity>
      </View>

      <Text
        style={{
          alignSelf: "center",
          fontSize: 18,
          fontWeight: "bold",
          color: "white",
        }}
      >
        {" "}
        Search
      </Text>
      <Text
        style={{
          alignSelf: "center",
          fontSize: 14,
          fontWeight: "bold",
          color: "white",
        }}
      >
        ({res}) Results
      </Text>
      {/* <View

style={{height:100,marginTop:50,}}>
<Image style={{ alignSelf:'center',height:'80%', resizeMode:'contain',width:'65%'}} source={require('../images/logofinal3.jpg')}/>

</View> */}

      <View
        style={{
          marginHorizontal: 20,
          justifyContent: "center",
          borderRadius: 20,
          backgroundColor: "white",
          marginTop: 10,
          flexDirection: "row",
        }}
      >
        <TextInput
          style={{
            backgroundColor: "white",
            width: "90%",
            height: 40,
            paddingHorizontal: 10,
            borderRadius: 20,
          }}
          onChangeText={(text) => onChangeText(text)}
          onSubmitEditing={(Text) => searchingApi(Text)}
          
          // this.callingVehicleContainerService()
          placeholder="Search vehicle by LOT number"
          placeholderTextColor="grey"
          underlineColorAndroid="transparent"
        ></TextInput>

        <Feather
          style={{ alignSelf: "center" }}
          size={18}
          color="grey"
          name="search"
        />
      </View>
      <View style={{ width: deviceWidth, paddingHorizontal: 20, marginTop: 5 }}>
        <FlatList
          style={{ marginBottom: 110 }}
          data={vehicleList}
          renderItem={renderVehicle}
          keyExtractor={(item, index) => index}
 
        />
      </View>

    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22,
  },
  modalView: {
    margin: 20,
    backgroundColor: "white",
    borderRadius: 20,
    padding: 35,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
    margin: 5
  },
  buttonClose: {
    backgroundColor: "#2196F3",
  },
  textStyle: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center",
  },
  modalBtn: {
    flexDirection: 'row',
    justifyContent: 'center'
  }
});
export default Tracking;
