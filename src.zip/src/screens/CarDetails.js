import React, { useState, useEffect } from "react";
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  ImageBackground,
  FlatList,
  PermissionsAndroid,
  Share,
  StatusBar,
  TouchableOpacity,
  Modal,
  Image,
  Dimensions,
} from "react-native";
import Icon from "react-native-vector-icons/Entypo";
import AppColors from "../Colors/AppColors";
import AppConstance, {
  deviceHeight,
  deviceWidth,
} from "../constance/AppConstance";
import AppMessages from "../AppMessages/AppMesage";
import AppFonts from "../AppFont/AppFonts";
import MaterialIcons from "react-native-vector-icons/dist/MaterialIcons";
import MaterialCommunityIcons from "react-native-vector-icons/dist/MaterialCommunityIcons";
import Ionicons from "react-native-vector-icons/dist/Ionicons";
import SimpleLineIcons from "react-native-vector-icons/dist/SimpleLineIcons";
import Entypo from "react-native-vector-icons/dist/Entypo";
import { SliderBox } from "react-native-image-slider-box";
import RNFetchBlob from "rn-fetch-blob";
import Snackbar from "react-native-snackbar";
import Spinner from "react-native-loading-spinner-overlay";
import AppUrlCollection from "../UrlCollection/AppUrlCollection";
import NetInfo from "@react-native-community/netinfo";

const images1 = [
  "https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885__340.jpg",
  "https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885__340.jpg",
];
let imageBaseUrl;
const CarDetails = ({ route, navigation }) => {
  // console.log(" vehicle obj is" , JSON.stringify(route.params.vehicleObj.status) )
  const [vehicleDetails, setvehicleDetails] = useState();
  const [isFooterLoading, setisFooterLoading] = useState(false);
  const [isStopCallingAPI, setisStopCallingAPI] = useState(false);
  const [data, setData] = useState([]);
  const [showimagemodel, setshowimagemodel] = useState(false);
  const [isLoading, setLoading] = useState(true);

  // const { type  , datapre , baseImagePath } = route.params;

  const [imgpos, setimgpos] = useState(0);
  const [images, setimages] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  
  // callingVehicleDetailApi = async (isCallingFirsttime) => {
  const callingVehicleDetailApi = () => {
    NetInfo.fetch().then((state) => {
      if (state.isConnected == true) {
        var url = "";
        // this.setState({ isLoading: true, isFooterLoading: false })
        url =
          AppUrlCollection.VEHICLE_DETAIL + "?id=" + route.params.vehicleObj.id;

        fetch(url, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            authkey: AppConstance.USER_INFO.USER_TOKEN,
          },
        })
          .then((response) => response.json())
          .then((responseJson) => {
            if (responseJson.status == AppConstance.API_SUCESSCODE) {
              setData(responseJson.data.vehicle);
              let data = responseJson.data.vehicle;
              imageBaseUrl = responseJson.data.other.vehicle_image;
              if (data.images != undefined && data.images != null) {
                // setimg(responseJson.data.vehicle.images)
                for (let index = 0; index < data.images.length; index++) {
                  console.log("data.images", data.images[index].thumbnail);
                  const element = data.images[index].thumbnail;
                  images.push(imageBaseUrl + element);
                  console.log(element);
                }
              }
              // console.log("responseJson.data.vehicle", responseJson.data.vehicle)
            } else {
              setisFooterLoading(false);
              setisStopCallingAPI(true);
              console.log(responseJson.message);
            }
          })
          .catch((error) => {
            console.warn(error);
          })
          .finally(() => setLoading(false));
      } else setModalVisible(true)
    });
  };

  useEffect(() => {
    callingVehicleDetailApi();
  }, []);
  // console.log("data.images", data.images)
  // console.log("data.images",data.images.thumbnail)
  return (
    <SafeAreaView
      style={{ flex: 1, backgroundColor: "white", height: deviceHeight }}
    >
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          // Alert.alert("Modal has been closed.");
          setModalVisible(!modalVisible);
        }}
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <Text style={styles.modalText}>
              Connect to the Internet and Retry
            </Text>
            <View style={styles.modalBtn}>
            <TouchableOpacity
              style={[styles.button, styles.buttonClose]}
              onPress={() => {
                setModalVisible(!modalVisible);
              }}
            >
              <Text style={styles.textStyle}>Close</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.button, styles.buttonClose]}
              onPress={() => {
                setModalVisible(!modalVisible);
                callingVehicleDetailApi()
              }}
            >
              <Text style={styles.textStyle}>Retry</Text>
            </TouchableOpacity>
            
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={showimagemodel} animationType="fade">
        <View
          style={{
            justifyContent: "center",
            backgroundColor: "black",
            height: deviceHeight,
          }}
        >
          <View style={{ backgroundColor: "black" }}>
            <SliderBox
              images={images}
              sliderBoxHeight={deviceHeight * 0.5}
              dotColor="#FFEE58"
              inactiveDotColor="#90A4AE"
              dotStyle={{
                width: 10,
                height: 10,
                marginHorizontal: -4,
                padding: 0,
                margin: 0,
              }}
              resizeMethod={"resize"}
              resizeMode={"cover"}
              circleLoop
              currentImageEmitter={(index) => {}}
              paginationBoxStyle={{
                alignItems: "center",
                alignSelf: "center",
                justifyContent: "center",
                alignSelf: "center",
              }}
              ImageComponentStyle={{ width: "100%", marginTop: 0 }}
            />

            <TouchableOpacity
              onPress={() => {
                setshowimagemodel(false);
              }}
              style={{ alignSelf: "center", marginTop: 10 }}
            >
              <MaterialCommunityIcons
                color="red"
                name="close-circle-outline"
                size={40}
              />
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <ImageBackground
        source={require("../images/bg.png")}
        resizeMode="stretch"
        style={{
          width: deviceWidth,
          height: deviceHeight,
          position: "absolute",
        }}
      />
      {/* <Toolbar toggle={this.props.toggle} headerName='DASHBOARD' isFilterIconShow={false} isInnerScreen={false} /> */}
      <View
        style={{
          width: deviceWidth,
          flexDirection: "row",
          paddingHorizontal: 13,
          paddingVertical: 15,
          height: 55,
        }}
      >
        <TouchableOpacity
          style={{ justifyContent: "center", width: "6%" }}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="chevron-back" size={25} color="white" />
        </TouchableOpacity>

        <View style={{ width: "88%", justifyContent: "center" }}>
          <Text
            style={{
              alignSelf: "center",
              color: "white",
              fontWeight: "bold",
              fontSize: 20,
            }}
          >
            Vehicle Details
          </Text>
        </View>

        <View style={{ width: "6%" }}></View>
      </View>
      {isLoading ? (
        <Text> Loading... </Text>
      ) : (
        <ScrollView style={{ width: deviceWidth }}>
          <SliderBox
            images={images}
            sliderBoxHeight={210}
            dotColor="#FFEE58"
            inactiveDotColor="#90A4AE"
            dotStyle={{
              width: 10,
              height: 10,
              borderRadius: 15,
              marginHorizontal: -6,
              padding: 0,
              margin: 0,
            }}
            resizeMethod={"resize"}
            resizeMode={"cover"}
            circleLoop
            currentImageEmitter={(index) => {}}
            onCurrentImagePressed={(index) =>
              //setcurrentimg()
              // console.warn(`image ${index} pressed`)
              setshowimagemodel(true)
            }
            paginationBoxStyle={{
              alignItems: "center",
              alignSelf: "center",
              justifyContent: "center",
              alignSelf: "center",
            }}
            ImageComponentStyle={{
              borderRadius: 15,
              width: "95%",
              marginTop: 8,
            }}
          />

          <View
            style={{
              height: 40,
              justifyContent: "center",
              marginTop: 10,
              shadowColor: "grey",
              borderRadius: 10,
              shadowOffset: { width: 3, height: 4 },
              shadowOpacity: 0.6,
              shadowRadius: 1,
              elevation: 5,
              marginBottom: 10,
              backgroundColor: "orange",
            }}
          >
            <Text style={{ alignSelf: "center", fontSize: 18 }}>
              Vehicle Information
            </Text>
          </View>

          <View
            style={{
              flexDirection: "column",
              justifyContent: "center",
              backgroundColor: "#F2F3F4",
              shadowColor: "grey",
              shadowOffset: { width: 3, height: 3 },
              shadowOpacity: 0.6,
              shadowRadius: 1,
              elevation: 5,
              alignSelf: "center",
              borderRadius: 10,
              borderWidth: 0.2,
              marginTop: 1,
              paddingHorizontal: 10,
              width: "95%",
            }}
          >
            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                lot{" "}
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.lot_number}
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                VIN{" "}
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.vin}
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                YEAR MAKE MODEL{" "}
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.year}
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                PURCHASE DATE{" "}
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.purchase_date}
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                DELIVERED DATE{" "}
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.towingRequest.deliver_date != null &&
                data.towingRequest.deliver_date != "" &&
                data.towingRequest.deliver_date != undefined
                  ? data.towingRequest.deliver_date
                  : "--"}
                {/* deliver_date */}
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                Key{" "}
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.keys != null && data.keys != "" && data.keys != undefined
                  ? data.keys
                  : "--"}
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                Title{" "}
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.vehicleExports.title != null &&
                data.vehicleExports.title != "" &&
                data.vehicleExports.title != undefined
                  ? data.vehicleExports.title
                  : "--"}
                {/* Title */}
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                Buyer Number{" "}
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                6949466
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                State City{" "}
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.customerUser.state != null &&
                data.customerUser.state != "" &&
                data.customerUser.state != undefined
                  ? data.customerUser.state
                  : "--"}
                {/* state */}
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                Loading Port{" "}
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.vehicleExports.export.port_of_loading != null &&
                data.vehicleExports.export.port_of_loading != "" &&
                data.vehicleExports.export.port_of_loading != undefined
                  ? data.vehicleExports.export.port_of_loading
                  : "--"}
                {/* port */}
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                Status{" "}
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {route.params.vehicleObj.status}
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                NOTE{" "}
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.towingRequest.note != null &&
                data.towingRequest.note != "" &&
                data.towingRequest.note != undefined
                  ? data.towingRequest.note
                  : "--"}
              </Text>
            </View>
          </View>
          <View
            style={{
              height: 50,
              justifyContent: "center",
              marginTop: 10,
              shadowColor: "grey",
              borderRadius: 10,
              shadowOffset: { width: 3, height: 4 },
              shadowOpacity: 0.6,
              shadowRadius: 1,
              elevation: 5,
              marginBottom: 10,
              backgroundColor: "orange",
            }}
          >
            <Text style={{ alignSelf: "center", fontSize: 18 }}>
              Container Information
            </Text>
          </View>

          <View
            style={{
              flexDirection: "column",
              justifyContent: "center",
              shadowColor: "grey",
              backgroundColor: "#F2F3F4",
              shadowOffset: { width: 3, height: 3 },
              shadowOpacity: 0.6,
              shadowRadius: 1,
              marginTop: 1,
              paddingHorizontal: 15,
              alignSelf: "center",
              borderRadius: 10,
              borderWidth: 0.2,
              marginTop: 1,
              width: "95%",
            }}
          >
            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                Container No.{" "}
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.container_number}
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                Loaded Date{" "}
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.vehicleExports.export.loading_date != null &&
                data.vehicleExports.export.loading_date != "" &&
                data.vehicleExports.export.loading_date != undefined
                  ? data.vehicleExports.export.loading_date
                  : "--"}
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                Export Date
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.vehicleExports.export.export_date != null &&
                data.vehicleExports.export.export_date != "" &&
                data.vehicleExports.export.export_date != undefined
                  ? data.vehicleExports.export.export_date
                  : "--"}
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                ETA{" "}
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.vehicleExports.export.eta != null &&
                data.vehicleExports.export.eta != "" &&
                data.vehicleExports.export.eta != undefined
                  ? data.vehicleExports.export.eta
                  : "--"}
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                Arrived Date{" "}
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.vehicleExports.export.arrival_date != null &&
                data.vehicleExports.export.arrival_date != "" &&
                data.vehicleExports.export.arrival_date != undefined
                  ? data.vehicleExports.export.arrival_date
                  : "--"}
              </Text>
            </View>
          </View>

          <View
            style={{
              height: 40,
              justifyContent: "center",
              marginTop: 10,
              shadowColor: "grey",
              borderRadius: 10,
              shadowOffset: { width: 3, height: 4 },
              shadowOpacity: 0.6,
              shadowRadius: 1,
              elevation: 5,
              marginBottom: 10,
              backgroundColor: "orange",
            }}
          >
            <Text style={{ alignSelf: "center", fontSize: 18 }}>INVOICE</Text>
          </View>

          <View
            style={{
              flexDirection: "column",
              justifyContent: "center",
              marginTop: 1,
              shadowColor: "grey",
              shadowOffset: { width: 3, height: 3 },
              shadowOpacity: 0.6,
              shadowRadius: 1,
              marginTop: 1,
              paddingHorizontal: 15,
              alignSelf: "center",
              borderRadius: 10,
              borderWidth: 0.2,
              marginTop: 1,
              backgroundColor: "#F2F3F4",
              width: "95%",
            }}
          >
            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                Invoice#
              </Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.invoice != null &&
                data.invoice.invoice_number != null &&
                data.invoice.invoice_number != "" &&
                data.invoice.invoice_number != undefined
                  ? data.invoice.invoice_number
                  : "--"}
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{
                  color: "black",
                  paddingVertical: 2,
                  width: "30.4%",
                  fontSize: 14,
                }}
              >
                Vehicle purchase
              </Text>
              <Text>$</Text>
              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                2500
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{
                  color: "black",
                  paddingVertical: 2,
                  width: "30%",
                  fontSize: 14,
                }}
              >
                Shipping
              </Text>
              <Text>$</Text>

              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.invoice != null &&
                data.vehicleExports.shipping != null &&
                data.vehicleExports.shipping != "" &&
                data.vehicleExports.shipping != undefined
                  ? data.vehicleExports.export.shipping
                  : "--"}
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{
                  color: "black",
                  paddingVertical: 2,
                  width: "30%",
                  fontSize: 14,
                }}
              >
                Paid Amount
              </Text>
              <Text>$</Text>

              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.invoice != null &&
                data.invoice.paid_amount != null &&
                data.invoice.paid_amount != "" &&
                data.invoice.paid_amount != undefined
                  ? data.invoice.paid_amount
                  : "--"}
              </Text>
            </View>

            <View
              style={{
                width: "100%",
                flexDirection: "row",
                borderBottomWidth: 0.5,
                paddingVertical: 5,
                borderColor: "grey",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{
                  color: "black",
                  paddingVertical: 2,
                  width: "30%",
                  fontSize: 14,
                }}
              >
                Balance Amount
              </Text>
              <Text>$</Text>

              <Text
                style={{ color: "black", paddingVertical: 2, fontSize: 14 }}
              >
                {data.invoice != null &&
                data.invoice.balance_due != null &&
                data.invoice.balance_due != "" &&
                data.invoice.balance_due != undefined
                  ? data.invoice.balance_due
                  : "--"}
              </Text>
            </View>
            <View style={{ width: deviceWidth, height: 30 }}></View>
          </View>

          <View style={{ height: 5, width: deviceWidth }}></View>
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22,
  },
  modalView: {
    margin: 20,
    backgroundColor: "white",
    borderRadius: 20,
    padding: 35,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
    margin: 5,
  },
  buttonClose: {
    backgroundColor: "#2196F3",
  },
  textStyle: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center",
  },
  modalBtn: {
    flexDirection: "row",
    justifyContent: "center",
  },
});

export default CarDetails;
