import React, { Component } from "react";
import {
  View,
  Modal,
  SafeAreaView,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Image,
  ScrollView,
  BackHandler,
} from "react-native";
// import Elavation from '../styles/Elavation';
import AppColors from "../Colors/AppColors";
import AppConstance, {
  deviceHeight,
  deviceWidth,
} from "../constance/AppConstance";
import AppFonts from "../AppFont/AppFonts";
// import Toolbar from './Toolbar';
import AppUrlCollection from "../UrlCollection/AppUrlCollection";
// import { heightPercentageToDP } from '../styles/ResponsiveScreen';
import RNFetchBlob from "rn-fetch-blob";
import { Appbar } from "react-native-paper";
import {
  Content,
  List,
  Header,
  Body,
  Title,
  ListItem,
  Container,
  Left,
  Right,
  Icon,
  Badge,
} from "native-base";
import AsyncStorage from "@react-native-community/async-storage";
import Ionicons from "react-native-vector-icons/Ionicons";
import Slideshow from "react-native-image-slider-show-razzium";
import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons";
import NetInfo from "@react-native-community/netinfo";

const { config, fs } = RNFetchBlob;

let exportObj = null;
let baseImagePath = null;
let vehicleList = null;
var isCallingWithoutLogin = null;

var exportImageBasePath = "";
var vehicleImageBAsePath = "";
class ExportDetailsScreen extends Component {
  constructor(props) {
    super(props);
    exportObj = props.route.params.ExportObj;
    console.log("absdfjsl", props.route.params.ExportObj);
    // vehicleList = this.props.navigation.state.params.vehicleList;
    // isCallingWithoutLogin = this.props.navigation.state.params.isCallingWithoutLogin;
    this.state = {
      exportDetailObj: "",
      vehicleList: [],
      locationList: [],
      imageList: [],
      drawerview: false,
      showimagemodel: false,
      isModalVisible: false,
    };
  }

  Logout = () => {
    AsyncStorage.setItem("ISUSERLOGIN", "0");
    AppConstance.IS_USER_LOGIN = "0";

    AsyncStorage.setItem("auth_key", " ");
    AppConstance.USER_TOKEN_KEY = " ";

    AsyncStorage.setItem("user_id", " ");
    AppConstance.USER_ID = " ";

    AsyncStorage.removeItem(AppConstance.USER_INFO_OBJ);
    this.setState({ drawerview: false });
    this.props.navigation.navigate("AppDrawer1");
  };
  componentDidMount() {
    BackHandler.addEventListener("hardwareBackPress", this.handleBackPress);

    this.callingExportDetailAPI();
  }

  componentWillUnmount() {
    BackHandler.removeEventListener("hardwareBackPress", this.handleBackPress);
  }

  handleBackPress = () => {
    this.props.navigation.goBack();
    return true;
  };

  callingExportDetailAPI = () => {
    NetInfo.fetch().then((state) => {
      if (state.isConnected == true) {
        console.log(exportObj.id);
        fetch(AppUrlCollection.EXPORT_DETAIL + "exportId=" + exportObj.id, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            authkey: AppConstance.USER_INFO.USER_TOKEN,
          },
        })
          .then((response) => response.json())
          .then((responseJson) => {
            console.log("export detail ", responseJson);
            if (responseJson.status == AppConstance.API_SUCESSCODE) {
              this.setState({ vehicleList: responseJson.data.export.vehicle });
             
            } else {

              console.log("failure");
            }
          })
          .catch((error) => {
            console.warn(error);
          });
      } else this.setState({isModalVisible: true})
    });
  };



  // render my vehicle content
  renderMyVehileList = ({ item, index }) => {
    if (isCallingWithoutLogin) {
      return (
        <View
          style={{
            flexDirection: "row",
            height: 50,
            justifyContent: "center",
            alignContent: "center",
            alignItems: "center",
          }}
        >
          <Text style={{ color: AppColors.textColor, fontSize: 14, flex: 1 }}>
            {item.vehicle.year != null && item.vehicle.year != ""
              ? item.vehicle.year
              : "-"}
          </Text>
          <Text style={{ color: AppColors.textColor, fontSize: 14, flex: 1 }}>
            {item.vehicle.make != null && item.vehicle.make != ""
              ? item.vehicle.make
              : "-"}
          </Text>
          <Text style={{ color: AppColors.textColor, fontSize: 14, flex: 1 }}>
            {item.vehicle.model != null && item.vehicle.model != ""
              ? item.vehicle.model
              : "-"}
          </Text>
          <Text style={{ color: AppColors.textColor, fontSize: 14, flex: 1 }}>
            {item.vehicle.lot_number != null && item.vehicle.lot_number != ""
              ? item.vehicle.lot_number
              : "-"}
          </Text>
          <TouchableOpacity
            onPress={() =>
              this.props.navigation.navigate("VehcilContainerDetailScreen", {
                vehicleObj: item,
              })
            }
          >
            <Text style={{ fontSize: 14, color: AppColors.textColor }}>
              VIEW
            </Text>
            {/* <MaterialCommunityIcons name='eye' color={AppColors.textColor} size={18} /> */}
          </TouchableOpacity>
        </View>
      );
    } else {
      return (
        <View
          style={{
            flexDirection: "row",
            height: 50,
            justifyContent: "center",
            alignContent: "center",
            alignItems: "center",
          }}
        >
          <Text style={{ color: AppColors.textColor, fontSize: 14, flex: 1 }}>
            {item.year != null && item.year != "" ? item.year : "-"}
          </Text>
          <Text style={{ color: AppColors.textColor, fontSize: 14, flex: 1 }}>
            {item.make != null && item.make != "" ? item.make : "-"}
          </Text>
          <Text style={{ color: AppColors.textColor, fontSize: 14, flex: 1 }}>
            {item.model != null && item.model != "" ? item.model : "-"}
          </Text>
          <Text style={{ color: AppColors.textColor, fontSize: 14, flex: 1 }}>
            {item.lot_number != null && item.lot_number != ""
              ? item.lot_number
              : "-"}
          </Text>
          <TouchableOpacity
            onPress={() =>
              this.props.navigation.navigate("CarDetails", { vehicleObj: item })
            }
          >
            <Text style={{ fontSize: 14, color: AppColors.textColor }}>
              VIEW
            </Text>
            {/* <MaterialCommunityIcons name='eye' color={AppColors.textColor} size={18} /> */}
          </TouchableOpacity>
        </View>
      );
    }
  };


  render() {
    return (
      <SafeAreaView style={styles.screen}>
          
          <Modal
          animationType="slide"
          transparent={true}
          visible={this.state.isModalVisible}
          onRequestClose={() => {
            Alert.alert("Modal has been closed.");
            this.setState({ isModalVisible: false });
          }}
        >
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <Text style={styles.modalText}>
                Connect to the Internet and Retry
              </Text>
              <View style={styles.modalBtn}>
                <TouchableOpacity
                  style={[styles.button, styles.buttonClose]}
                  onPress={() => {
                    this.setState({ isModalVisible: false });
                  }}
                >
                  <Text style={styles.textStyle}>Close</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.button, styles.buttonClose]}
                  onPress={() => {
                    this.setState({ isModalVisible: false });
                    this.callingSearchAPI();
                  }}
                >
                  <Text style={styles.textStyle}>Retry</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>


        <Appbar
          style={{
            backgroundColor: AppColors.Headercolor,
            flexDirection: "row",
            width: deviceWidth,
            backgroundColor: AppColors.Headercolor,
            justifyContent: "space-between",
            padding: 10,
            elevation: 0,
          }}
        >
          <TouchableOpacity
            style={{ width: 60, height: 60, justifyContent: "center" }}
            onPress={() => {
              this.props.navigation.goBack();
            }}
          >
            <Ionicons name="ios-chevron-back" color="grey" size={30} />
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              width: 60,
              height: 60,
              alignContent: "center",
              alignItems: "center",
              justifyContent: "center",
            }}
            //   onPress={() => this.props.navigation.navigate('LoginScreen')}
          >
            <Text>Export </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              alignContent: "flex-end",
              alignSelf: "flex-end",
            }}
            onPress={() => this.setState({ drawerview: true })}
          >
            <Image
              source={require("../images/dispatched2.png")}
              style={{
                width: 30,
                height: 30,
                marginRight: 10,
                alignSelf: "center",
              }}
              resizeMode="contain"
            />
          </TouchableOpacity>
        </Appbar>

        <View style={{ backgroundColor: AppColors.toolbarColor }}>
          <Text
            style={{
              paddingVertical: 15,
              fontWeight: "700",
              alignSelf: "center",
              color: "white",
            }}
          >
            Container Detail{" "}
          </Text>
          {/* <Toolbar headerName={'Container Detail'} isFilterIconShow={true} isInnerScreen={true} /> */}
        </View>
        <ScrollView behaviour="height">
          <View style={{ flex: 1 }}>
            {this.state.imageList.length > 0 ? (
              <View style={{ width: "100%" }}>
                <Slideshow
                  height={deviceHeight * 0.25}
                  onPress={() => {
                    this.setState({ showimagemodel: true });
                  }}
                  dataSource={this.state.imageList}
                />
              </View>
            ) : (
              <View style={{ width: "100%", height: deviceHeight * 0.25 }}>
                <Image
                  source={require("../images/logofinal.jpeg")}
                  style={{ height: "100%", width: "100%", alignSelf: "center" }}
                  resizeMode="stretch"
                  resizeMethod="resize"
                />
              </View>
            )}
            <View
              style={{
                flexDirection: "row",
                position: "absolute",
                bottom: 0,
                right: 0,
                marginBottom: 8,
                marginRight: 10,
              }}
            ></View>
            <View
              elevation={3}
              style={{
                width: deviceWidth,
                height: 50,
                backgroundColor: AppColors.toolbarColor,
                justifyContent: "center",
                alignContent: "center",
                alignItems: "center",
                marginBottom: 10,
              }}
            >
              <Text style={{ fontSize: 16, color: AppColors.white }}>
                Container Details
              </Text>
            </View>

            <View
              style={{
                flex: 1,
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <View style={styles.detailMainViewStyle}>
                <Text style={styles.detailHeadingTxtStyle}>
                  ContainerNo ID :{" "}
                </Text>
                <Text style={styles.detailValueTxtStyle}>
                  {exportObj.container_number}
                </Text>
              </View>

              <View style={styles.dividerStyleView} />

              <View style={styles.detailMainViewStyle}>
                <Text style={styles.detailHeadingTxtStyle}>
                  Port of loading:{" "}
                </Text>
                <Text style={styles.detailValueTxtStyle}>
                  {exportObj.port_of_loading != undefined &&
                  exportObj.port_of_loading != ""
                    ? exportObj.port_of_loading
                    : "-"}
                </Text>
              </View>

              <View style={styles.dividerStyleView} />

              <View style={styles.detailMainViewStyle}>
                <Text style={styles.detailHeadingTxtStyle}>Export Date: </Text>
                <Text style={styles.detailValueTxtStyle}>
                  {exportObj.export_date}
                </Text>
              </View>

              <View style={styles.dividerStyleView} />

              <View style={styles.detailMainViewStyle}>
                <Text style={styles.detailHeadingTxtStyle}>
                  Port of discharge:{" "}
                </Text>
                <Text style={styles.detailValueTxtStyle}>
                  {exportObj.portOfDischarge != undefined &&
                  exportObj.portOfDischarge != null &&
                  exportObj.portOfDischarge.port_name != null &&
                  exportObj.portOfDischarge.port_name != ""
                    ? exportObj.portOfDischarge.port_name
                    : "-"}
                </Text>
              </View>

              <View style={styles.dividerStyleView} />

              <View style={styles.detailMainViewStyle}>
                <Text style={styles.detailHeadingTxtStyle}>ETA: </Text>
                <Text style={styles.detailValueTxtStyle}>{exportObj.eta}</Text>
              </View>

              <View style={styles.dividerStyleView} />

              <View style={styles.detailMainViewStyle}>
                <Text style={styles.detailHeadingTxtStyle}>
                  Arrived Date :{" "}
                </Text>
                <Text style={styles.detailValueTxtStyle}>
                  {exportObj.arrival_date != null
                    ? exportObj.arrival_date
                    : "-"}
                </Text>
              </View>
              <View style={styles.dividerStyleView} />

              <View style={{ flex: 1 }}>
                <View style={styles.detailMainViewStyle}>
                  <Text style={styles.detailHeadingTxtStyle}>Note : </Text>
                  <Text style={styles.detailValueTxtStyle}>
                    {exportObj.special_instruction}
                  </Text>
                </View>
                <View style={styles.dividerStyleView} />
              </View>
            </View>
            <View
              elevation={3}
              style={{
                width: deviceWidth,
                height: 50,
                backgroundColor: AppColors.toolbarColor,
                justifyContent: "center",
                alignContent: "center",
                alignItems: "center",
                marginBottom: 10,
              }}
            >
              <Text style={{ fontSize: 16, color: AppColors.white }}>
                Vehicle
              </Text>
            </View>
            <View
              style={{
                marginLeft: 10,
                marginRight: 10,
                flexDirection: "row",
                height: 30,
                justifyContent: "center",
                alignContent: "center",
                alignItems: "center",
              }}
            >
              <Text
                style={{ color: AppColors.textColor, fontSize: 14, flex: 1 }}
              >
                YEAR
              </Text>
              <Text
                style={{ color: AppColors.textColor, fontSize: 14, flex: 1 }}
              >
                MAKE
              </Text>
              <Text
                style={{ color: AppColors.textColor, fontSize: 14, flex: 1 }}
              >
                MODEL
              </Text>
              <Text
                style={{ color: AppColors.textColor, fontSize: 14, flex: 1 }}
              >
                LOT NO
              </Text>
              <View style={{ width: 18, height: 1 }} />
            </View>

            <FlatList
              style={{ flex: 1, marginLeft: 10, marginRight: 10 }}
              data={this.state.vehicleList}
              renderItem={this.renderMyVehileList}
              keyExtractor={(item, index) => index}
              extraData={this.state}
              ItemSeparatorComponent={() => (
                <View
                  style={{
                    width: deviceWidth,
                    height: 1,
                    backgroundColor: AppColors.toolbarColor,
                  }}
                />
              )}
            />
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }
}

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: AppColors.white,
  },

  screen: {
    flex: 1,
    height: deviceHeight,
    width: deviceWidth,
    backgroundColor: "white",
  },
  detailMainViewStyle: {
    flexDirection: "row",
    flex: 1,
    width: deviceWidth * 0.85,
    alignContent: "center",
    alignItems: "center",
    justifyContent: "center",
  },
  detailHeadingTxtStyle: {
    fontSize: 14,
    color: AppColors.textColor,
    flex: 0.95,
  },
  detailValueTxtStyle: {
    fontSize: 14,
    color: AppColors.textColor,
    flex: 1,
  },
  dividerStyleView: {
    width: deviceWidth * 0.85,
    height: 1,
    backgroundColor: "#A9A9A9",
    marginTop: 13,
    marginBottom: 8,
  },
    centeredView: {
      flex: 1,
      justifyContent: "center",
      alignItems: "center",
      marginTop: 22,
    },
    modalView: {
      margin: 20,
      backgroundColor: "white",
      borderRadius: 20,
      padding: 35,
      alignItems: "center",
      shadowColor: "#000",
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 4,
      elevation: 5,
    },
    button: {
      borderRadius: 20,
      padding: 10,
      elevation: 2,
      margin: 5
    },
    buttonClose: {
      backgroundColor: "#2196F3",
    },
    textStyle: {
      color: "white",
      fontWeight: "bold",
      textAlign: "center",
    },
    modalText: {
      marginBottom: 15,
      textAlign: "center",
    },
    modalBtn: {
      flexDirection: 'row',
      justifyContent: 'center'
    }
  });
export default ExportDetailsScreen;
