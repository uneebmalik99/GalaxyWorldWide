import React, { useState, useEffect } from "react";
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  Button,
  ImageBackground,
  TextInput,
  StatusBar,
  TouchableOpacity,
  Image,
  Dimensions,
  Modal,
} from "react-native";
import AsyncStorage from "@react-native-community/async-storage";
import LinearGradient from "react-native-linear-gradient";
import Icon from "react-native-vector-icons/Entypo";
import AppColors from "../Colors/AppColors";
import AppConstance, {
  deviceHeight,
  deviceWidth,
} from "../constance/AppConstance";
import AppFonts from "../AppFont/AppFonts";
import MaterialCommunityIcons from "react-native-vector-icons/dist/MaterialCommunityIcons";
import AntDesign from "react-native-vector-icons/dist/AntDesign";
import Ionicons from "react-native-vector-icons/dist/Ionicons";
import MaterialIcons from "react-native-vector-icons/dist/MaterialIcons";
import Feather from "react-native-vector-icons/dist/Feather";
import Fontisto from "react-native-vector-icons/dist/Fontisto";
import SimpleLineIcons from "react-native-vector-icons/dist/SimpleLineIcons";
import AppUrlCollection from "../UrlCollection/AppUrlCollection";
import Spinner from "react-native-loading-spinner-overlay";
import NetInfo from "@react-native-community/netinfo";
// import { white } from "react-native-paper/lib/typescript/src/styles/colors";

const Signin = ({ navigation }) => {
  // const [email ,setemail] = useState('Moontest')
  const [email, setemail] = useState("20190267");
  const [modalVisible, setModalVisible] = useState(false);
  // const [pass ,setpass] =useState('Haq@123')
  const [pass, setpass] = useState("20190267");

  const [spinner, setspinner] = useState(false);

  const callingLoginApi = async () => {
    NetInfo.fetch().then((state) => {
      if (state.isConnected == true) {
        setspinner(true);
        if (email.trim().length == 0) {
          alert("username can not be blank");
          setspinner(false);
        } else if (pass.trim().length == 0) {
          alert("password can not be blank");
          setspinner(false);
        } else {
          var url = AppUrlCollection.BASE_URL + "login";

          var value = new FormData();

          value.append("username", email);
          value.append("password", pass);

          console.log("Login_key_vale ", value);
          fetch(url, {
            method: "POST",
            headers: {
              "Content-Type": "multipart/form-data",
            },
            body: value,
          })
            .then((response) => response.json())
            .then((responseJson) => {
              setspinner(false);

              console.log(responseJson);
              loginServiceCall(responseJson);

              // this.setState({ isLoading: false })
            })
            .catch((error) => {
              setspinner(false);
              alert("Error while login" + error);
              // this.setState({ isLoading: false })
              console.warn(error);
            });
        }
        //  this.props.navigation.navigate('NavigationSideScreen')
      } else setModalVisible(true);
    });
  };

  const loginServiceCall = async (responseJson) => {
    console.warn(responseJson);

    if (responseJson.status == AppConstance.API_SUCESSCODE) {
      AppConstance.IS_USER_LOGIN = "1";
      // this.props.navigation.push('Dashboard');

      //AppConstance.showSnackbarMessage(responseJson.message)
      callingUserService(responseJson.data.auth_key);
    } else {
      alert(responseJson.message);
    }
  };

  const callingUserService = async (authKey) => {
    var url = AppUrlCollection.USER;
    fetch(url, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",

        authkey: authKey,
      },
      // body: value,
    })
      .then((response) => response.json())
      .then((responseJson) => {
        console.warn("USER::: ", responseJson);
        AsyncStorage.setItem(
          AppConstance.USER_INFO_OBJ,
          JSON.stringify(responseJson.data)
        );

        //  this._storeData();
        AsyncStorage.setItem("ISUSERLOGIN", "1");
        alert(responseJson.data);

        let data = responseJson.data;
        console.warn("json value", data);

        alert(data.auth_key);
        AppConstance.USER_INFO.USER_ID = data.id;
        AppConstance.USER_INFO.USER_NAME = data.username;
        AppConstance.USER_INFO.USER_TOKEN = data.auth_key;
        AppConstance.USER_INFO.USER_EMAIL = data.email;
        AppConstance.USER_INFO.USER_STATUS = data.status;
        AppConstance.USER_INFO.USER_DELETED = data.is_deleted;
        AppConstance.USER_INFO.USER_ADDRESS1 = data.address_line_1;
        AppConstance.USER_INFO.USER_ADDRESS2 = data.address_line_2;
        AppConstance.USER_INFO.USER_CITY = data.city;
        AppConstance.USER_INFO.USER_STATE = data.state;
        AppConstance.USER_INFO.USER_ZIP_CODE = data.zip_code;
        AppConstance.USER_INFO.USER_MOBILE = data.phone;
        AppConstance.USER_INFO.USER_FAX = data.fax;
        AppConstance.USER_INFO.USER_CUSTOMER_NAME = data.customer_name;
        AppConstance.USER_INFO.USER_IS_BLOCK = data.is_blocked;

        // AsyncStorage.setItem('k','1')

        navigation.navigate("AppDrawer");

        setspinner(false);
      })
      .catch((error) => {
        this.setState({ isLoading: false });
        console.warn("user error" + error);
      });
  };

  return (
    <SafeAreaView style={{ backgroundColor: "white", height: deviceHeight }}>
      <View
        style={{
          width: deviceWidth,
          height: deviceHeight * 0.35,
        }}
      >
        <ImageBackground
          style={{ width: "100%", height: "100%" }}
          source={require("../images/signin.png")}
        ></ImageBackground>
      </View>
      <View
        style={{
          backgroundColor: AppColors.white,
          height: deviceHeight * 0.65,
          marginTop: -15,
          borderTopRightRadius: 15,
          borderTopLeftRadius: 15,
          padding: 20,
        }}
      >
        <Text style={{ fontSize: 20 }}>WELCOME TO GALAXY</Text>
        <Text style={{ marginTop: 20, color: "gray" }}>
          {" "}
          Sign in to continue
        </Text>

        <View
          style={{
            borderBottomColor: "gray",
            borderBottomWidth: 0.5,
            marginTop: 50,
            paddingHorizontal: 15,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <MaterialIcons
            name="email"
            style={{ justifyContent: "center", alignSelf: "center" }}
            size={20}
          />
          <View style={{ marginHorizontal: 15, width: "85%" }}>
            <Text>EMAIL</Text>
            <TextInput
              style={{
                height: 30,
                width: "100%",
                fontSize: 16,
              }}
              // onChangeText={text => onChangeText(text)}
              onChangeText={(text) => {
                setemail(text);
              }}
              placeholder="Username"
              underlineColorAndroid="transparent"
            />
          </View>
        </View>
        <View
          style={{
            borderBottomColor: "gray",
            borderBottomWidth: 0.5,
            marginTop: 25,
            paddingHorizontal: 15,
            flexDirection: "row",
            alignItems: "flex-start",
            justifyContent: "flex-start",
          }}
        >
          <SimpleLineIcons
            name="lock"
            style={{ justifyContent: "center", alignSelf: "center" }}
            size={20}
          />
          <View style={{ marginHorizontal: 15, width: "83%", }}>
            <Text>PASSWORD</Text>
            <TextInput
              style={{
                height: 30,
                width: "100%",
                fontSize: 16,
              }}
              // onChangeText={text => onChangeText(text)}
              onChangeText={(text) => setpass(text)}
              placeholder="Password"
              inlineImageLeft="search_icon"
            />
          </View>
          <MaterialCommunityIcons
            name="eye"
            style={{  alignSelf: "center" }}
            size={20}
            color={"gray"}
          />
        </View>
        <View>
          <TouchableOpacity
            onPress={() => callingLoginApi()}
            style={{
              width: "100%",
              marginVertical: 25,
              justifyContent: "center",
              borderRadius: 10,
              // borderColor: "white",
              // borderWidth: 1,
              alignSelf: "center",
              backgroundColor: "#29AB87",
              height: 55,
            }}
          >
            <Text style={{ color: "white", fontSize: 16, alignSelf: "center" }}>
              SIGN IN
            </Text>
          </TouchableOpacity>

          <TouchableOpacity style={{ marginTop: 1 }}>
            <Text
              style={{
                alignSelf: "center",
                color: "gray",
                fontSize: 14,
              }}
            >
              Forgot Password?
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22,
  },
  modalView: {
    margin: 20,
    backgroundColor: "white",
    borderRadius: 20,
    padding: 35,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
    margin: 5,
  },
  buttonClose: {
    backgroundColor: "#2196F3",
  },
  textStyle: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center",
  },
  modalBtn: {
    flexDirection: "row",
    justifyContent: "center",
  },
});
export default Signin;
